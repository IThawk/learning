package com.gupao.netty;

import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.util.concurrent.EventExecutorGroup;

/**
 * Created by Jack
 * Create in 14:36 2018/11/23
 * Description:
 */
public class MyServerHandler extends ChannelInboundHandlerAdapter {
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        String request= (String) msg;
        System.out.println("From Client: "+request);
        String response="From Server Hello: "+request;
        ctx.writeAndFlush(response);
    }
}
